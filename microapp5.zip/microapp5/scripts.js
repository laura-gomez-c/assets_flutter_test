function showContent() {
  var temp = document.getElementsByTagName("template")[0];
  var clon = temp.content.cloneNode(true);
  document.body.appendChild(clon);
}

window.onload = function() {
	// Get a reference to the 'Send Message' button.
	var btn = document.getElementById('getLocation');

	// A function to handle sending messages.
	function getLocation(e) {
		// Prevent any default browser behaviour.
		e.preventDefault();

		//window.flutter_inappwebview.callHandler('getLocation', 'There is the postMessage!');
		window.flutter_inappwebview.callHandler('getLocation')
                  .then(function(result) {
                    // print to the console the data coming
                    // from the Flutter side.
                    console.log(JSON.stringify(result));
                    alert(JSON.stringify(result));
                    alert('Location: ' + JSON.stringify(result));
                });
	}

	// Add an event listener that will execute the sendMessage() function
	// when the send button is clicked.
	btn.addEventListener('click', getLocation);
}